# 아이온2 파티 배정 - GitHub Pages 배포본

이 폴더의 웹 버전은 별도 설치나 서버 없이 GitHub Pages에서 실행되는 정적 웹 앱입니다.

## 업로드할 파일

GitHub 저장소의 최상위 폴더에 아래 파일을 올립니다.

- `index.html`
- `style.css`
- `app.js`
- `.nojekyll`

`README_GitHub_Pages.md`는 사용 설명서이므로 함께 올려도 됩니다.

## GitHub Pages 켜기

1. GitHub에서 새 저장소를 만듭니다.
2. 위 파일들을 저장소 최상위에 업로드하고 커밋합니다.
3. 저장소의 **Settings → Pages**로 이동합니다.
4. **Build and deployment**에서 **Deploy from a branch**를 선택합니다.
5. Branch는 `main`, Folder는 `/(root)`를 선택하고 저장합니다.
6. 잠시 뒤 `https://GitHub아이디.github.io/저장소이름/` 주소로 열립니다.

예: 저장소 이름이 `aion2-party-planner`라면
`https://GitHub아이디.github.io/aion2-party-planner/`

## 저장 방식

- **저장**: 현재 편성을 JSON 파일로 내려받습니다.
- **불러오기**: 저장한 JSON 파일을 다시 불러옵니다.
- 브라우저에도 작업 중인 내용이 자동 임시 저장됩니다.
- GitHub Pages는 정적 호스팅이므로 여러 기기 사이에 자동 동기화되지는 않습니다. 필요한 경우 JSON 파일을 저장해서 옮기면 됩니다.

## 로컬에서 열기

`index.html`을 더블 클릭해 브라우저로 열어도 실행됩니다.
